// ============================================================
// DairyDirect — Full Firebase App
// Firebase config: dairy-app-58c60
// ============================================================
// SETUP INSTRUCTIONS:
// 1. npm install firebase
// 2. Replace firebaseConfig below with yours (already filled!)
// 3. npm start
// ============================================================

import { useState, useEffect } from "react";
import { initializeApp } from "firebase/app";
import {
  getAuth, createUserWithEmailAndPassword,
  signInWithEmailAndPassword, signOut, onAuthStateChanged
} from "firebase/auth";
import {
  getFirestore, doc, setDoc, getDoc, collection,
  addDoc, onSnapshot, updateDoc, query, where, orderBy, serverTimestamp
} from "firebase/firestore";

// ── YOUR FIREBASE CONFIG (already filled in!) ──────────────
const firebaseConfig = {
  apiKey: "AIzaSyAZsPDKduqvxyMPRgDNqjjdGcJV5djfzPA",
  authDomain: "dairy-app-58c60.firebaseapp.com",
  projectId: "dairy-app-58c60",
  storageBucket: "dairy-app-58c60.firebasestorage.app",
  messagingSenderId: "148391095657",
  appId: "1:148391095657:web:df1f802c0968c101ce61f8"
};

const app = initializeApp(firebaseConfig);
const auth = getAuth(app);
const db = getFirestore(app);

// ── CONSTANTS ───────────────────────────────────────────────
const G = "#16a34a";
const fmt = n => `₹${Number(n).toFixed(0)}`;
const uid = () => Date.now().toString(36) + Math.random().toString(36).slice(2);

// ── SHARED UI COMPONENTS ────────────────────────────────────
const Avatar = ({ name, size = 44, bg = "#dcfce7", color = G }) => (
  <div style={{ width: size, height: size, borderRadius: "50%", background: bg, color, display: "flex", alignItems: "center", justifyContent: "center", fontWeight: 600, fontSize: size * 0.35, flexShrink: 0 }}>
    {name?.split(" ").map(w => w[0]).join("").slice(0, 2).toUpperCase()}
  </div>
);

const Badge = ({ label, type = "green" }) => {
  const map = { green: ["#dcfce7", "#15803d"], red: ["#fee2e2", "#dc2626"], amber: ["#fef9c3", "#ca8a04"], blue: ["#dbeafe", "#1d4ed8"] };
  const [bg, col] = map[type] || map.green;
  return <span style={{ background: bg, color: col, borderRadius: 20, padding: "3px 10px", fontSize: 11, fontWeight: 700, letterSpacing: 0.3 }}>{label}</span>;
};

const Btn = ({ children, onClick, variant = "primary", full, sm, disabled, loading }) => {
  const styles = {
    primary: { background: G, color: "#fff", border: "none" },
    secondary: { background: "#f1f5f9", color: "#334155", border: "none" },
    danger: { background: "#fee2e2", color: "#dc2626", border: "none" },
    ghost: { background: "transparent", color: G, border: "1.5px solid #d1fae5" },
  };
  return (
    <button onClick={onClick} disabled={disabled || loading}
      style={{ ...styles[variant], borderRadius: 12, padding: sm ? "7px 14px" : "11px 20px", fontWeight: 600, cursor: (disabled || loading) ? "not-allowed" : "pointer", fontSize: sm ? 13 : 14, width: full ? "100%" : "auto", opacity: (disabled || loading) ? 0.6 : 1, transition: "opacity .15s" }}>
      {loading ? "Please wait…" : children}
    </button>
  );
};

const Input = ({ label, error, ...props }) => (
  <div style={{ marginBottom: 14 }}>
    {label && <div style={{ fontSize: 12, fontWeight: 600, color: "#64748b", marginBottom: 5, textTransform: "uppercase", letterSpacing: 0.5 }}>{label}</div>}
    <input style={{ width: "100%", border: `1.5px solid ${error ? "#dc2626" : "#e2e8f0"}`, borderRadius: 10, padding: "10px 14px", fontSize: 14, outline: "none", boxSizing: "border-box", background: "#fff", color: "#1e293b" }}
      onFocus={e => e.target.style.borderColor = G}
      onBlur={e => e.target.style.borderColor = error ? "#dc2626" : "#e2e8f0"}
      {...props} />
    {error && <div style={{ fontSize: 11, color: "#dc2626", marginTop: 3 }}>{error}</div>}
  </div>
);

const Card = ({ children, style, onClick }) => (
  <div onClick={onClick} style={{ background: "#fff", borderRadius: 16, padding: "14px 16px", marginBottom: 10, border: "1px solid #f1f5f9", boxShadow: "0 1px 4px rgba(0,0,0,0.04)", cursor: onClick ? "pointer" : "default", ...style }}>
    {children}
  </div>
);

const TopBar = ({ title, subtitle, onLogout }) => (
  <div style={{ background: "#fff", borderBottom: "1px solid #f1f5f9", padding: "14px 18px", display: "flex", justifyContent: "space-between", alignItems: "center", position: "sticky", top: 0, zIndex: 50 }}>
    <div>
      <div style={{ fontWeight: 700, fontSize: 17, color: "#0f172a" }}>{title}</div>
      {subtitle && <div style={{ fontSize: 12, color: "#94a3b8" }}>{subtitle}</div>}
    </div>
    {onLogout && (
      <button onClick={onLogout} style={{ background: "#fee2e2", border: "none", borderRadius: 10, padding: "7px 12px", color: "#dc2626", fontWeight: 600, fontSize: 12, cursor: "pointer" }}>
        ⏏ Logout
      </button>
    )}
  </div>
);

const BottomNav = ({ tabs, active, setActive }) => (
  <div style={{ position: "fixed", bottom: 0, left: "50%", transform: "translateX(-50%)", width: "100%", maxWidth: 430, background: "#fff", borderTop: "1px solid #f1f5f9", display: "flex", zIndex: 99, boxShadow: "0 -4px 20px rgba(0,0,0,0.06)" }}>
    {tabs.map(t => (
      <button key={t.key} onClick={() => setActive(t.key)}
        style={{ flex: 1, padding: "10px 0 8px", border: "none", background: "none", cursor: "pointer", display: "flex", flexDirection: "column", alignItems: "center", gap: 3, position: "relative" }}>
        <div style={{ fontSize: 20 }}>{t.icon}</div>
        <div style={{ fontSize: 10, fontWeight: active === t.key ? 700 : 400, color: active === t.key ? G : "#94a3b8" }}>{t.label}</div>
        {t.badge > 0 && <div style={{ position: "absolute", top: 6, right: "18%", background: "#dc2626", color: "#fff", borderRadius: "50%", width: 16, height: 16, fontSize: 9, fontWeight: 700, display: "flex", alignItems: "center", justifyContent: "center" }}>{t.badge}</div>}
        {active === t.key && <div style={{ width: 4, height: 4, borderRadius: "50%", background: G }} />}
      </button>
    ))}
  </div>
);

const Spinner = () => (
  <div style={{ display: "flex", justifyContent: "center", padding: 40 }}>
    <div style={{ width: 32, height: 32, border: `3px solid #dcfce7`, borderTop: `3px solid ${G}`, borderRadius: "50%", animation: "spin 0.8s linear infinite" }} />
    <style>{`@keyframes spin{to{transform:rotate(360deg)}}`}</style>
  </div>
);

// ── ROOT APP ─────────────────────────────────────────────────
export default function App() {
  const [user, setUser] = useState(undefined); // undefined = loading
  const [userProfile, setUserProfile] = useState(null);
  const [tab, setTab] = useState("home");
  const [cart, setCart] = useState([]);

  useEffect(() => {
    const unsub = onAuthStateChanged(auth, async (firebaseUser) => {
      if (firebaseUser) {
        const snap = await getDoc(doc(db, "users", firebaseUser.uid));
        if (snap.exists()) {
          setUserProfile({ uid: firebaseUser.uid, email: firebaseUser.email, ...snap.data() });
        }
        setUser(firebaseUser);
      } else {
        setUser(null);
        setUserProfile(null);
      }
    });
    return unsub;
  }, []);

  const logout = async () => {
    await signOut(auth);
    setCart([]);
    setTab("home");
  };

  if (user === undefined) return (
    <div style={{ minHeight: "100vh", display: "flex", alignItems: "center", justifyContent: "center", background: "#f0fdf4" }}>
      <div style={{ textAlign: "center" }}>
        <div style={{ fontSize: 48, marginBottom: 12 }}>🥛</div>
        <Spinner />
        <div style={{ color: "#64748b", marginTop: 10, fontSize: 14 }}>Loading DairyDirect…</div>
      </div>
    </div>
  );

  if (!user) return <AuthScreen />;

  return (
    <div style={{ fontFamily: "'Segoe UI',sans-serif", background: "#f8fafc", minHeight: "100vh", maxWidth: 430, margin: "0 auto" }}>
      {userProfile?.role === "customer"
        ? <CustomerApp user={userProfile} cart={cart} setCart={setCart} onLogout={logout} tab={tab} setTab={setTab} />
        : userProfile?.role === "owner"
          ? <OwnerApp user={userProfile} onLogout={logout} tab={tab} setTab={setTab} />
          : <div style={{ padding: 40, textAlign: "center", color: "#64748b" }}><Spinner /><p>Setting up your account…</p></div>
      }
    </div>
  );
}

// ── AUTH SCREEN (Login + Register) ──────────────────────────
function AuthScreen() {
  const [mode, setMode] = useState("welcome"); // welcome | login | register
  const [role, setRole] = useState("customer");
  const [form, setForm] = useState({ name: "", email: "", phone: "", shopName: "", password: "", confirm: "" });
  const [err, setErr] = useState("");
  const [loading, setLoading] = useState(false);

  const register = async () => {
    if (!form.name || !form.email || !form.password) return setErr("Please fill all fields.");
    if (form.password !== form.confirm) return setErr("Passwords do not match.");
    if (form.password.length < 6) return setErr("Password must be at least 6 characters.");
    if (role === "owner" && !form.shopName) return setErr("Please enter your shop name.");
    setLoading(true); setErr("");
    try {
      const cred = await createUserWithEmailAndPassword(auth, form.email, form.password);
      const uid2 = cred.user.uid;
      if (role === "owner") {
        const shopId = uid();
        await setDoc(doc(db, "users", uid2), { name: form.name, email: form.email, phone: form.phone, role: "owner", shopId });
        await setDoc(doc(db, "shops", shopId), {
          name: form.shopName, ownerId: uid2, ownerName: form.name,
          phone: form.phone, email: form.email, open: true,
          products: [
            { id: uid(), name: "Full Cream Milk", price: 60, unit: "1L", icon: "🥛" },
            { id: uid(), name: "Toned Milk", price: 50, unit: "1L", icon: "🥛" },
            { id: uid(), name: "Paneer", price: 80, unit: "200g", icon: "🧀" },
            { id: uid(), name: "Butter", price: 55, unit: "100g", icon: "🧈" },
            { id: uid(), name: "Curd", price: 40, unit: "500g", icon: "🍶" },
          ],
          createdAt: serverTimestamp()
        });
      } else {
        await setDoc(doc(db, "users", uid2), { name: form.name, email: form.email, phone: form.phone, role: "customer" });
      }
    } catch (e) {
      setErr(e.message.replace("Firebase: ", "").replace(/\(auth.*\)/, ""));
    }
    setLoading(false);
  };

  const login = async () => {
    if (!form.email || !form.password) return setErr("Please enter email and password.");
    setLoading(true); setErr("");
    try {
      await signInWithEmailAndPassword(auth, form.email, form.password);
    } catch (e) {
      setErr("Incorrect email or password. Please try again.");
    }
    setLoading(false);
  };

  if (mode === "welcome") return (
    <div style={{ minHeight: "100vh", display: "flex", flexDirection: "column" }}>
      <div style={{ background: "linear-gradient(160deg,#f0fdf4,#dcfce7)", padding: "52px 28px 36px", textAlign: "center" }}>
        <div style={{ width: 80, height: 80, background: "#fff", borderRadius: 24, margin: "0 auto 16px", display: "flex", alignItems: "center", justifyContent: "center", fontSize: 38, boxShadow: "0 4px 20px rgba(22,163,74,0.15)" }}>🥛</div>
        <h1 style={{ margin: "0 0 6px", fontSize: 28, fontWeight: 800, color: "#0f172a" }}>DairyDirect</h1>
        <p style={{ margin: 0, color: "#64748b", fontSize: 15 }}>Fresh dairy delivered to your door</p>
      </div>
      <div style={{ flex: 1, padding: "28px 24px", display: "flex", flexDirection: "column", gap: 12 }}>
        <div style={{ fontWeight: 700, fontSize: 16, color: "#0f172a", marginBottom: 4 }}>Welcome! Continue as</div>
        {[
          { key: "customer", label: "Customer", sub: "Browse shops & order dairy products", icon: "🛒" },
          { key: "owner", label: "Shop Owner", sub: "Manage your shop, products & orders", icon: "🏪" },
        ].map(r => (
          <div key={r.key} onClick={() => { setRole(r.key); setMode("login"); setForm({ name: "", email: "", phone: "", shopName: "", password: "", confirm: "" }); setErr(""); }}
            style={{ background: "#fff", border: "2px solid #f1f5f9", borderRadius: 16, padding: "16px 18px", cursor: "pointer", display: "flex", alignItems: "center", gap: 14, boxShadow: "0 1px 4px rgba(0,0,0,0.04)" }}>
            <div style={{ width: 48, height: 48, background: "#f0fdf4", borderRadius: 14, display: "flex", alignItems: "center", justifyContent: "center", fontSize: 24, flexShrink: 0 }}>{r.icon}</div>
            <div>
              <div style={{ fontWeight: 700, color: "#0f172a", fontSize: 15 }}>{r.label}</div>
              <div style={{ fontSize: 12, color: "#64748b", marginTop: 2 }}>{r.sub}</div>
            </div>
            <div style={{ marginLeft: "auto", color: "#94a3b8", fontSize: 18 }}>›</div>
          </div>
        ))}
      </div>
    </div>
  );

  return (
    <div style={{ minHeight: "100vh", display: "flex", flexDirection: "column" }}>
      <div style={{ background: "linear-gradient(160deg,#f0fdf4,#dcfce7)", padding: "36px 28px 28px", textAlign: "center" }}>
        <div style={{ fontSize: 36, marginBottom: 8 }}>{role === "owner" ? "🏪" : "🛒"}</div>
        <h2 style={{ margin: 0, fontSize: 22, fontWeight: 800, color: "#0f172a" }}>{role === "owner" ? "Shop Owner" : "Customer"}</h2>
        <p style={{ margin: "4px 0 0", color: "#64748b", fontSize: 14 }}>{mode === "login" ? "Sign in to your account" : "Create a new account"}</p>
      </div>
      <div style={{ flex: 1, padding: "24px 24px 40px", overflowY: "auto" }}>
        <button onClick={() => { setMode("welcome"); setErr(""); }} style={{ background: "none", border: "none", color: "#64748b", cursor: "pointer", padding: "0 0 16px", fontSize: 14 }}>‹ Back</button>

        {mode === "register" && <>
          <Input label="Full Name" value={form.name} onChange={e => setForm({ ...form, name: e.target.value })} placeholder="e.g. Rahul Sharma" />
          {role === "owner" && <Input label="Shop Name" value={form.shopName} onChange={e => setForm({ ...form, shopName: e.target.value })} placeholder="e.g. Fresh Dairy Farm" />}
          <Input label="Phone Number" value={form.phone} onChange={e => setForm({ ...form, phone: e.target.value })} placeholder="+91 98765 43210" type="tel" />
        </>}
        <Input label="Email Address" value={form.email} onChange={e => setForm({ ...form, email: e.target.value })} placeholder="your@email.com" type="email" />
        <Input label="Password" value={form.password} onChange={e => setForm({ ...form, password: e.target.value })} placeholder="Min 6 characters" type="password" />
        {mode === "register" && <Input label="Confirm Password" value={form.confirm} onChange={e => setForm({ ...form, confirm: e.target.value })} placeholder="Repeat password" type="password" />}

        {err && <div style={{ background: "#fee2e2", border: "1px solid #fecaca", borderRadius: 10, padding: "10px 14px", color: "#dc2626", fontSize: 13, marginBottom: 14 }}>⚠️ {err}</div>}

        <Btn full loading={loading} onClick={mode === "login" ? login : register}>
          {mode === "login" ? "Sign In →" : "Create Account →"}
        </Btn>

        <div style={{ textAlign: "center", marginTop: 16, fontSize: 14, color: "#64748b" }}>
          {mode === "login" ? <>Don't have an account? <span onClick={() => { setMode("register"); setErr(""); }} style={{ color: G, fontWeight: 600, cursor: "pointer" }}>Register</span></> : <>Already have an account? <span onClick={() => { setMode("login"); setErr(""); }} style={{ color: G, fontWeight: 600, cursor: "pointer" }}>Sign In</span></>}
        </div>
      </div>
    </div>
  );
}

// ── CUSTOMER APP ─────────────────────────────────────────────
function CustomerApp({ user, cart, setCart, onLogout, tab, setTab }) {
  const cartCount = cart.reduce((a, i) => a + i.qty, 0);
  const [showLogout, setShowLogout] = useState(false);

  const addToCart = (shopId, prod) => setCart(prev => {
    const ex = prev.find(i => i.id === prod.id);
    if (ex) return prev.map(i => i.id === prod.id ? { ...i, qty: i.qty + 1 } : i);
    return [...prev, { ...prod, shopId, qty: 1 }];
  });

  const tabs = [
    { key: "home", icon: "🏪", label: "Shops" },
    { key: "cart", icon: "🛒", label: "Cart", badge: cartCount },
    { key: "history", icon: "📋", label: "My Orders" },
  ];

  return (
    <div>
      {showLogout && (
        <div style={{ position: "fixed", inset: 0, background: "rgba(0,0,0,0.45)", display: "flex", alignItems: "flex-end", justifyContent: "center", zIndex: 999 }}>
          <div style={{ background: "#fff", borderRadius: "24px 24px 0 0", padding: 28, width: "100%", maxWidth: 430, boxSizing: "border-box" }}>
            <div style={{ textAlign: "center", marginBottom: 24 }}>
              <div style={{ fontSize: 44, marginBottom: 10 }}>👋</div>
              <div style={{ fontWeight: 700, fontSize: 20, color: "#0f172a" }}>Leaving so soon?</div>
              <div style={{ color: "#64748b", fontSize: 14, marginTop: 6 }}>Logged in as <b>{user.name}</b></div>
            </div>
            <div style={{ display: "flex", gap: 10 }}>
              <Btn onClick={() => setShowLogout(false)} variant="secondary" full>Stay</Btn>
              <Btn onClick={onLogout} variant="danger" full>Yes, Log Out</Btn>
            </div>
          </div>
        </div>
      )}
      <TopBar title="DairyDirect" subtitle={`Hello, ${user.name} 👋`} onLogout={() => setShowLogout(true)} />
      <div style={{ padding: "12px 14px 90px" }}>
        {tab === "home" && <ShopList addToCart={addToCart} cart={cart} />}
        {tab === "cart" && <CartScreen cart={cart} setCart={setCart} setTab={setTab} userId={user.uid} userName={user.name} />}
        {tab === "history" && <CustomerHistory userId={user.uid} />}
      </div>
      <BottomNav tabs={tabs} active={tab} setActive={setTab} />
    </div>
  );
}

function ShopList({ addToCart, cart }) {
  const [shops, setShops] = useState([]);
  const [selected, setSelected] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const unsub = onSnapshot(collection(db, "shops"), snap => {
      setShops(snap.docs.map(d => ({ id: d.id, ...d.data() })));
      setLoading(false);
    });
    return unsub;
  }, []);

  if (loading) return <Spinner />;

  if (selected) {
    const shop = shops.find(s => s.id === selected);
    return <ShopDetail shop={shop} addToCart={addToCart} cart={cart} back={() => setSelected(null)} />;
  }

  return (
    <div>
      <div style={{ marginBottom: 14 }}>
        <div style={{ fontWeight: 700, fontSize: 19, color: "#0f172a" }}>Nearby Shops</div>
        <div style={{ fontSize: 13, color: "#94a3b8" }}>{shops.length} shop{shops.length !== 1 ? "s" : ""} available</div>
      </div>
      {shops.length === 0 && <div style={{ textAlign: "center", color: "#94a3b8", padding: 40 }}>No shops available yet</div>}
      {shops.map(shop => (
        <Card key={shop.id} onClick={() => setSelected(shop.id)} style={{ display: "flex", gap: 14, alignItems: "center" }}>
          <div style={{ width: 54, height: 54, background: "#f0fdf4", borderRadius: 14, display: "flex", alignItems: "center", justifyContent: "center", fontSize: 28, flexShrink: 0 }}>🏪</div>
          <div style={{ flex: 1 }}>
            <div style={{ fontWeight: 700, fontSize: 15, color: "#0f172a" }}>{shop.name}</div>
            <div style={{ fontSize: 12, color: "#64748b" }}>{shop.products?.length || 0} products • 📞 {shop.phone}</div>
          </div>
          <div style={{ display: "flex", flexDirection: "column", alignItems: "flex-end", gap: 6 }}>
            <Badge label={shop.open ? "OPEN" : "CLOSED"} type={shop.open ? "green" : "red"} />
            <span style={{ color: G, fontSize: 18 }}>›</span>
          </div>
        </Card>
      ))}
    </div>
  );
}

function ShopDetail({ shop, addToCart, cart, back }) {
  const getQty = pid => cart.find(i => i.id === pid)?.qty || 0;
  return (
    <div>
      <button onClick={back} style={{ background: "none", border: "none", color: G, fontWeight: 600, cursor: "pointer", padding: "0 0 12px", fontSize: 14 }}>‹ Back to Shops</button>
      <Card style={{ display: "flex", alignItems: "center", gap: 14, marginBottom: 14 }}>
        <div style={{ width: 56, height: 56, background: "#f0fdf4", borderRadius: 14, display: "flex", alignItems: "center", justifyContent: "center", fontSize: 28 }}>🏪</div>
        <div style={{ flex: 1 }}>
          <div style={{ fontWeight: 700, fontSize: 17, color: "#0f172a" }}>{shop.name}</div>
          <div style={{ fontSize: 12, color: "#64748b" }}>📞 {shop.phone}</div>
          <div style={{ fontSize: 12, color: "#64748b" }}>✉️ {shop.email}</div>
        </div>
        <Badge label={shop.open ? "OPEN" : "CLOSED"} type={shop.open ? "green" : "red"} />
      </Card>
      {!shop.open && <div style={{ background: "#fee2e2", borderRadius: 12, padding: "12px 16px", color: "#dc2626", fontSize: 14, fontWeight: 600, marginBottom: 12, textAlign: "center" }}>🔒 This shop is currently closed</div>}
      <div style={{ fontWeight: 700, fontSize: 16, color: "#0f172a", marginBottom: 10 }}>Menu</div>
      {(shop.products || []).map(p => (
        <Card key={p.id} style={{ display: "flex", alignItems: "center", gap: 14 }}>
          <div style={{ fontSize: 28 }}>{p.icon}</div>
          <div style={{ flex: 1 }}>
            <div style={{ fontWeight: 600, color: "#0f172a" }}>{p.name}</div>
            <div style={{ fontSize: 12, color: "#94a3b8" }}>{p.unit}</div>
            <div style={{ fontWeight: 700, color: G, fontSize: 15, marginTop: 2 }}>{fmt(p.price)}</div>
          </div>
          {shop.open ? (
            getQty(p.id) > 0 ? (
              <div style={{ display: "flex", alignItems: "center", gap: 10, background: "#f0fdf4", borderRadius: 12, padding: "6px 12px" }}>
                <button onClick={() => { /* handled in cart */ }} style={{ background: "none", border: "none", color: G, fontWeight: 700, fontSize: 18, cursor: "pointer" }}>−</button>
                <span style={{ fontWeight: 700, minWidth: 18, textAlign: "center", color: G }}>{getQty(p.id)}</span>
                <button onClick={() => addToCart(shop.id, p)} style={{ background: "none", border: "none", color: G, fontWeight: 700, fontSize: 18, cursor: "pointer" }}>+</button>
              </div>
            ) : <Btn sm onClick={() => addToCart(shop.id, p)}>Add</Btn>
          ) : <span style={{ fontSize: 12, color: "#cbd5e1" }}>Unavailable</span>}
        </Card>
      ))}
    </div>
  );
}

function CartScreen({ cart, setCart, setTab, userId, userName }) {
  const [stage, setStage] = useState("cart");
  const [addr, setAddr] = useState("");
  const [orderId, setOrderId] = useState(null);
  const [loading, setLoading] = useState(false);

  const updateQty = (id, qty) => qty < 1 ? setCart(prev => prev.filter(i => i.id !== id)) : setCart(prev => prev.map(i => i.id === id ? { ...i, qty } : i));
  const total = cart.reduce((a, i) => a + i.price * i.qty, 0);
  const shopId = cart[0]?.shopId;

  const placeOrder = async () => {
    if (!addr.trim()) return;
    setLoading(true);
    try {
      const ref = await addDoc(collection(db, "orders"), {
        shopId, customerId: userId, customerName: userName,
        items: cart, address: addr, total,
        status: "Pending", createdAt: serverTimestamp()
      });
      setOrderId(ref.id);
      setCart([]);
      setStage("confirm");
    } catch (e) {
      alert("Failed to place order. Please try again.");
    }
    setLoading(false);
  };

  if (stage === "confirm") return (
    <div style={{ display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", minHeight: 360, textAlign: "center", padding: 20 }}>
      <div style={{ width: 80, height: 80, background: "#f0fdf4", borderRadius: "50%", display: "flex", alignItems: "center", justifyContent: "center", fontSize: 40, margin: "0 auto 18px" }}>✅</div>
      <div style={{ fontWeight: 800, fontSize: 22, color: "#0f172a" }}>Order Placed!</div>
      <div style={{ color: "#64748b", fontSize: 14, margin: "8px 0 6px" }}>Your order has been sent to the shop</div>
      <div style={{ background: "#f0fdf4", borderRadius: 10, padding: "8px 16px", color: G, fontWeight: 700, fontSize: 13, marginBottom: 24 }}>Order ID: #{orderId?.slice(-6)}</div>
      <Btn onClick={() => { setStage("cart"); setTab("history"); }}>View My Orders</Btn>
    </div>
  );

  if (cart.length === 0) return (
    <div style={{ textAlign: "center", padding: "60px 20px" }}>
      <div style={{ fontSize: 56, marginBottom: 12 }}>🛒</div>
      <div style={{ fontWeight: 700, fontSize: 18, color: "#0f172a" }}>Your cart is empty</div>
      <div style={{ color: "#94a3b8", fontSize: 14, marginTop: 6 }}>Browse shops and add products</div>
    </div>
  );

  if (stage === "checkout") return (
    <div>
      <button onClick={() => setStage("cart")} style={{ background: "none", border: "none", color: G, fontWeight: 600, cursor: "pointer", padding: "0 0 14px", fontSize: 14 }}>‹ Back to Cart</button>
      <div style={{ fontWeight: 700, fontSize: 19, color: "#0f172a", marginBottom: 14 }}>Checkout</div>
      <Card>
        <div style={{ fontWeight: 600, marginBottom: 10, color: "#0f172a" }}>Order Summary</div>
        {cart.map(i => <div key={i.id} style={{ display: "flex", justifyContent: "space-between", fontSize: 13, color: "#475569", marginBottom: 5 }}><span>{i.icon} {i.name} ×{i.qty}</span><span style={{ fontWeight: 600 }}>{fmt(i.price * i.qty)}</span></div>)}
        <div style={{ borderTop: "1px solid #f1f5f9", marginTop: 10, paddingTop: 10, display: "flex", justifyContent: "space-between", fontWeight: 700, fontSize: 16 }}><span>Total</span><span style={{ color: G }}>{fmt(total)}</span></div>
      </Card>
      <Card>
        <div style={{ fontWeight: 600, marginBottom: 10, color: "#0f172a" }}>Delivery Address</div>
        <textarea value={addr} onChange={e => setAddr(e.target.value)} placeholder="Enter your full delivery address..." style={{ width: "100%", border: "1.5px solid #e2e8f0", borderRadius: 10, padding: "10px 14px", fontSize: 14, resize: "none", height: 80, boxSizing: "border-box", fontFamily: "inherit" }} />
      </Card>
      <Btn full loading={loading} disabled={!addr.trim()} onClick={placeOrder}>Confirm & Place Order ✓</Btn>
    </div>
  );

  return (
    <div>
      <div style={{ fontWeight: 700, fontSize: 19, color: "#0f172a", marginBottom: 14 }}>Your Cart</div>
      {cart.map(item => (
        <Card key={item.id} style={{ display: "flex", alignItems: "center", gap: 12 }}>
          <div style={{ fontSize: 26 }}>{item.icon}</div>
          <div style={{ flex: 1 }}>
            <div style={{ fontWeight: 600, color: "#0f172a" }}>{item.name}</div>
            <div style={{ color: G, fontWeight: 700, fontSize: 14 }}>{fmt(item.price)} × {item.qty} = {fmt(item.price * item.qty)}</div>
          </div>
          <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
            <button onClick={() => updateQty(item.id, item.qty - 1)} style={{ width: 28, height: 28, borderRadius: 8, border: "1.5px solid #e2e8f0", background: "#fff", cursor: "pointer", fontWeight: 700, fontSize: 16 }}>−</button>
            <span style={{ fontWeight: 700, minWidth: 18, textAlign: "center" }}>{item.qty}</span>
            <button onClick={() => updateQty(item.id, item.qty + 1)} style={{ width: 28, height: 28, borderRadius: 8, background: G, border: "none", color: "#fff", cursor: "pointer", fontWeight: 700, fontSize: 16 }}>+</button>
          </div>
        </Card>
      ))}
      <Card style={{ background: "#f0fdf4", border: "1px solid #d1fae5" }}>
        <div style={{ display: "flex", justifyContent: "space-between", fontWeight: 700, fontSize: 17 }}><span>Total</span><span style={{ color: G }}>{fmt(total)}</span></div>
      </Card>
      <Btn full onClick={() => setStage("checkout")}>Proceed to Checkout →</Btn>
    </div>
  );
}

function CustomerHistory({ userId }) {
  const [orders, setOrders] = useState([]);
  const [loading, setLoading] = useState(true);
  const statusMap = { Pending: ["amber", "⏳"], Confirmed: ["green", "✅"], Delivered: ["blue", "📦"], Rejected: ["red", "❌"] };

  useEffect(() => {
    const q = query(collection(db, "orders"), where("customerId", "==", userId), orderBy("createdAt", "desc"));
    const unsub = onSnapshot(q, snap => {
      setOrders(snap.docs.map(d => ({ id: d.id, ...d.data() })));
      setLoading(false);
    });
    return unsub;
  }, [userId]);

  if (loading) return <Spinner />;

  return (
    <div>
      <div style={{ fontWeight: 700, fontSize: 19, color: "#0f172a", marginBottom: 14 }}>My Orders</div>
      {orders.length === 0 && <div style={{ textAlign: "center", color: "#94a3b8", padding: 40 }}>No orders yet</div>}
      {orders.map(o => {
        const [type, icon] = statusMap[o.status] || ["green", "📦"];
        return (
          <Card key={o.id}>
            <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 6 }}>
              <div style={{ fontWeight: 700, color: "#0f172a" }}>#{o.id.slice(-6)}</div>
              <Badge label={`${icon} ${o.status}`} type={type} />
            </div>
            <div style={{ fontSize: 12, color: "#94a3b8", marginBottom: 6 }}>{o.createdAt?.toDate?.()?.toLocaleString() || "Just now"}</div>
            {o.items?.map(i => <div key={i.id} style={{ fontSize: 13, color: "#475569" }}>{i.icon} {i.name} ×{i.qty}</div>)}
            <div style={{ fontWeight: 700, color: G, marginTop: 8, fontSize: 15 }}>{fmt(o.total)}</div>
            <div style={{ fontSize: 12, color: "#94a3b8", marginTop: 4 }}>📍 {o.address}</div>
          </Card>
        );
      })}
    </div>
  );
}

// ── OWNER APP ────────────────────────────────────────────────
function OwnerApp({ user, onLogout, tab, setTab }) {
  const [shop, setShop] = useState(null);
  const [orders, setOrders] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showLogout, setShowLogout] = useState(false);

  useEffect(() => {
    if (!user.shopId) return;
    const unsub = onSnapshot(doc(db, "shops", user.shopId), snap => {
      if (snap.exists()) setShop({ id: snap.id, ...snap.data() });
      setLoading(false);
    });
    return unsub;
  }, [user.shopId]);

  useEffect(() => {
    if (!user.shopId) return;
    const q = query(collection(db, "orders"), where("shopId", "==", user.shopId));
    const unsub = onSnapshot(q, snap => {
      setOrders(snap.docs.map(d => ({ id: d.id, ...d.data() })));
    });
    return unsub;
  }, [user.shopId]);

  const updateShop = async (upd) => {
    await updateDoc(doc(db, "shops", user.shopId), upd);
  };

  const updateOrder = async (id, status) => {
    await updateDoc(doc(db, "orders", id), { status });
  };

  const pendingCount = orders.filter(o => o.status === "Pending").length;

  const tabs = [
    { key: "home", icon: "🏠", label: "Dashboard" },
    { key: "products", icon: "🥛", label: "Products" },
    { key: "notif", icon: "🔔", label: "Orders", badge: pendingCount },
    { key: "history", icon: "📋", label: "History" },
    { key: "settings", icon: "⚙️", label: "Settings" },
  ];

  if (loading) return <Spinner />;

  return (
    <div>
      {showLogout && (
        <div style={{ position: "fixed", inset: 0, background: "rgba(0,0,0,0.45)", display: "flex", alignItems: "flex-end", justifyContent: "center", zIndex: 999 }}>
          <div style={{ background: "#fff", borderRadius: "24px 24px 0 0", padding: 28, width: "100%", maxWidth: 430, boxSizing: "border-box" }}>
            <div style={{ textAlign: "center", marginBottom: 24 }}>
              <div style={{ fontSize: 44, marginBottom: 10 }}>👋</div>
              <div style={{ fontWeight: 700, fontSize: 20, color: "#0f172a" }}>Leaving so soon?</div>
              <div style={{ color: "#64748b", fontSize: 14, marginTop: 6 }}>Logged in as <b>{user.name}</b></div>
            </div>
            <div style={{ display: "flex", gap: 10 }}>
              <Btn onClick={() => setShowLogout(false)} variant="secondary" full>Stay</Btn>
              <Btn onClick={onLogout} variant="danger" full>Yes, Log Out</Btn>
            </div>
          </div>
        </div>
      )}
      <TopBar title={shop?.name || "My Shop"} subtitle="Owner Dashboard" onLogout={() => setShowLogout(true)} />
      <div style={{ padding: "12px 14px 90px" }}>
        {tab === "home" && <OwnerDashboard shop={shop} orders={orders} updateShop={updateShop} />}
        {tab === "products" && <ProductsManager shop={shop} updateShop={updateShop} />}
        {tab === "notif" && <OrderNotifications orders={orders.filter(o => o.status === "Pending")} updateOrder={updateOrder} />}
        {tab === "history" && <OrderHistory orders={orders} updateOrder={updateOrder} />}
        {tab === "settings" && <OwnerSettings shop={shop} updateShop={updateShop} />}
      </div>
      <BottomNav tabs={tabs} active={tab} setActive={setTab} />
    </div>
  );
}

function OwnerDashboard({ shop, orders, updateShop }) {
  const revenue = orders.filter(o => o.status === "Delivered").reduce((a, o) => a + o.total, 0);
  const stats = [
    { label: "Total Orders", val: orders.length, icon: "📦" },
    { label: "Pending", val: orders.filter(o => o.status === "Pending").length, icon: "⏳" },
    { label: "Delivered", val: orders.filter(o => o.status === "Delivered").length, icon: "✅" },
    { label: "Revenue", val: fmt(revenue), icon: "💰" },
  ];
  return (
    <div>
      <Card style={{ background: shop?.open ? "#f0fdf4" : "#fff7f7", border: `1px solid ${shop?.open ? "#d1fae5" : "#fee2e2"}`, display: "flex", justifyContent: "space-between", alignItems: "center" }}>
        <div>
          <div style={{ fontWeight: 700, fontSize: 16, color: "#0f172a" }}>{shop?.name}</div>
          <div style={{ fontSize: 13, color: "#64748b" }}>Tap to change status</div>
        </div>
        <button onClick={() => updateShop({ open: !shop?.open })}
          style={{ background: shop?.open ? G : "#dc2626", color: "#fff", border: "none", borderRadius: 24, padding: "10px 20px", fontWeight: 700, cursor: "pointer", fontSize: 14 }}>
          {shop?.open ? "🟢 OPEN" : "🔴 CLOSED"}
        </button>
      </Card>
      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 10, marginBottom: 12 }}>
        {stats.map(st => (
          <div key={st.label} style={{ background: "#fff", border: "1px solid #f1f5f9", borderRadius: 14, padding: "14px 16px", textAlign: "center" }}>
            <div style={{ fontSize: 24 }}>{st.icon}</div>
            <div style={{ fontWeight: 700, fontSize: 20, color: "#0f172a" }}>{st.val}</div>
            <div style={{ fontSize: 12, color: "#94a3b8" }}>{st.label}</div>
          </div>
        ))}
      </div>
      <div style={{ fontWeight: 700, fontSize: 16, color: "#0f172a", marginBottom: 10 }}>Recent Orders</div>
      {orders.slice(0, 3).map(o => (
        <Card key={o.id} style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
          <div>
            <div style={{ fontWeight: 600, color: "#0f172a", fontSize: 14 }}>#{o.id.slice(-6)} — {o.customerName}</div>
            <div style={{ fontSize: 12, color: "#94a3b8" }}>{o.status} · {o.createdAt?.toDate?.()?.toLocaleString() || "Just now"}</div>
          </div>
          <div style={{ fontWeight: 700, color: G }}>{fmt(o.total)}</div>
        </Card>
      ))}
      {orders.length === 0 && <div style={{ textAlign: "center", color: "#94a3b8", padding: 30, fontSize: 14 }}>No orders yet</div>}
    </div>
  );
}

function ProductsManager({ shop, updateShop }) {
  const [adding, setAdding] = useState(false);
  const [editing, setEditing] = useState(null);
  const [form, setForm] = useState({ name: "", price: "", unit: "", icon: "🥛" });
  const icons = ["🥛", "🧀", "🧈", "🍶", "🫙", "🍼", "🧁", "🍦"];

  const save = async () => {
    if (!form.name || !form.price) return;
    let products = [...(shop.products || [])];
    if (editing !== null) {
      products = products.map(p => p.id === editing ? { ...p, ...form, price: +form.price } : p);
    } else {
      products.push({ id: uid(), ...form, price: +form.price });
    }
    await updateShop({ products });
    setForm({ name: "", price: "", unit: "", icon: "🥛" }); setAdding(false); setEditing(null);
  };

  const del = async (id) => {
    await updateShop({ products: shop.products.filter(p => p.id !== id) });
  };

  const startEdit = p => { setForm({ name: p.name, price: p.price, unit: p.unit, icon: p.icon || "🥛" }); setEditing(p.id); setAdding(true); };

  return (
    <div>
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 14 }}>
        <div style={{ fontWeight: 700, fontSize: 19, color: "#0f172a" }}>Products</div>
        <Btn sm onClick={() => { setAdding(true); setEditing(null); setForm({ name: "", price: "", unit: "", icon: "🥛" }); }}>+ Add</Btn>
      </div>
      {adding && (
        <Card style={{ border: `1.5px solid ${G}` }}>
          <div style={{ fontWeight: 700, color: G, marginBottom: 14 }}>{editing ? "Edit Product" : "New Product"}</div>
          <div style={{ marginBottom: 12 }}>
            <div style={{ fontSize: 12, fontWeight: 600, color: "#64748b", marginBottom: 6, textTransform: "uppercase", letterSpacing: 0.5 }}>Icon</div>
            <div style={{ display: "flex", gap: 8, flexWrap: "wrap" }}>
              {icons.map(ic => <button key={ic} onClick={() => setForm({ ...form, icon: ic })} style={{ fontSize: 22, background: form.icon === ic ? "#f0fdf4" : "none", border: form.icon === ic ? `2px solid ${G}` : "2px solid transparent", borderRadius: 10, padding: 4, cursor: "pointer" }}>{ic}</button>)}
            </div>
          </div>
          <Input label="Product Name" value={form.name} onChange={e => setForm({ ...form, name: e.target.value })} placeholder="e.g. Full Cream Milk" />
          <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 10 }}>
            <Input label="Price (₹)" type="number" value={form.price} onChange={e => setForm({ ...form, price: e.target.value })} placeholder="60" />
            <Input label="Unit" value={form.unit} onChange={e => setForm({ ...form, unit: e.target.value })} placeholder="1L" />
          </div>
          <div style={{ display: "flex", gap: 8, marginTop: 4 }}>
            <Btn variant="secondary" onClick={() => { setAdding(false); setEditing(null); }}>Cancel</Btn>
            <Btn full onClick={save}>Save Product</Btn>
          </div>
        </Card>
      )}
      {(shop.products || []).map(p => (
        <Card key={p.id} style={{ display: "flex", alignItems: "center", gap: 14 }}>
          <div style={{ fontSize: 28 }}>{p.icon || "🥛"}</div>
          <div style={{ flex: 1 }}>
            <div style={{ fontWeight: 600, color: "#0f172a" }}>{p.name}</div>
            <div style={{ fontSize: 12, color: "#94a3b8" }}>{p.unit}</div>
            <div style={{ fontWeight: 700, color: G }}>{fmt(p.price)}</div>
          </div>
          <div style={{ display: "flex", gap: 6 }}>
            <Btn sm variant="ghost" onClick={() => startEdit(p)}>Edit</Btn>
            <Btn sm variant="danger" onClick={() => del(p.id)}>Del</Btn>
          </div>
        </Card>
      ))}
    </div>
  );
}

function OrderNotifications({ orders, updateOrder }) {
  return (
    <div>
      <div style={{ fontWeight: 700, fontSize: 19, color: "#0f172a", marginBottom: 14 }}>New Orders 🔔</div>
      {orders.length === 0 && <div style={{ textAlign: "center", color: "#94a3b8", padding: 40 }}>🎉 No pending orders</div>}
      {orders.map(o => (
        <Card key={o.id} style={{ borderLeft: `4px solid ${G}`, borderRadius: "0 16px 16px 0" }}>
          <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 6 }}>
            <div style={{ fontWeight: 700, color: "#0f172a" }}>Order #{o.id.slice(-6)}</div>
            <Badge label="⏳ Pending" type="amber" />
          </div>
          <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 8 }}>
            <Avatar name={o.customerName} size={32} />
            <span style={{ fontSize: 14, color: "#475569" }}>{o.customerName}</span>
          </div>
          {o.items?.map(i => <div key={i.id} style={{ fontSize: 13, color: "#475569" }}>{i.icon || "🥛"} {i.name} ×{i.qty} — {fmt(i.price * i.qty)}</div>)}
          <div style={{ fontWeight: 700, color: G, margin: "8px 0 4px", fontSize: 15 }}>Total: {fmt(o.total)}</div>
          <div style={{ fontSize: 12, color: "#94a3b8", marginBottom: 10 }}>📍 {o.address}</div>
          <div style={{ display: "flex", gap: 8 }}>
            <Btn full onClick={() => updateOrder(o.id, "Confirmed")}>✅ Confirm</Btn>
            <Btn full variant="danger" onClick={() => updateOrder(o.id, "Rejected")}>❌ Reject</Btn>
          </div>
        </Card>
      ))}
    </div>
  );
}

function OrderHistory({ orders, updateOrder }) {
  const statusMap = { Pending: ["amber", "⏳"], Confirmed: ["green", "✅"], Delivered: ["blue", "📦"], Rejected: ["red", "❌"] };
  return (
    <div>
      <div style={{ fontWeight: 700, fontSize: 19, color: "#0f172a", marginBottom: 14 }}>Order History</div>
      {orders.length === 0 && <div style={{ textAlign: "center", color: "#94a3b8", padding: 40 }}>No orders yet</div>}
      {orders.map(o => {
        const [type, icon] = statusMap[o.status] || ["green", "📦"];
        return (
          <Card key={o.id}>
            <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 6 }}>
              <div style={{ fontWeight: 700, color: "#0f172a" }}>#{o.id.slice(-6)} — {o.customerName}</div>
              <Badge label={`${icon} ${o.status}`} type={type} />
            </div>
            <div style={{ fontSize: 12, color: "#94a3b8", marginBottom: 6 }}>{o.createdAt?.toDate?.()?.toLocaleString() || "Just now"}</div>
            {o.items?.map(i => <div key={i.id} style={{ fontSize: 13, color: "#475569" }}>{i.icon || "🥛"} {i.name} ×{i.qty}</div>)}
            <div style={{ fontWeight: 700, color: G, marginTop: 8 }}>{fmt(o.total)}</div>
            <div style={{ fontSize: 12, color: "#94a3b8", marginTop: 4 }}>📍 {o.address}</div>
            {o.status === "Confirmed" && (
              <div style={{ marginTop: 10 }}>
                <Btn full sm onClick={() => updateOrder(o.id, "Delivered")}>Mark as Delivered 📦</Btn>
              </div>
            )}
          </Card>
        );
      })}
    </div>
  );
}

function OwnerSettings({ shop, updateShop }) {
  const [form, setForm] = useState({ name: shop?.name || "", phone: shop?.phone || "", email: shop?.email || "" });
  const [saved, setSaved] = useState(false);
  const [loading, setLoading] = useState(false);

  const save = async () => {
    setLoading(true);
    await updateShop(form);
    setSaved(true);
    setLoading(false);
    setTimeout(() => setSaved(false), 2500);
  };

  return (
    <div>
      <div style={{ fontWeight: 700, fontSize: 19, color: "#0f172a", marginBottom: 14 }}>Settings</div>
      <Card>
        <div style={{ display: "flex", alignItems: "center", gap: 14, marginBottom: 20 }}>
          <Avatar name={shop?.name} size={52} />
          <div>
            <div style={{ fontWeight: 700, fontSize: 16, color: "#0f172a" }}>{shop?.name}</div>
            <div style={{ fontSize: 13, color: "#94a3b8" }}>Shop Profile</div>
          </div>
        </div>
        <Input label="Shop Name" value={form.name} onChange={e => setForm({ ...form, name: e.target.value })} />
        <Input label="Phone Number" value={form.phone} onChange={e => setForm({ ...form, phone: e.target.value })} />
        <Input label="Email Address" value={form.email} onChange={e => setForm({ ...form, email: e.target.value })} />
        <Btn full loading={loading} onClick={save}>{saved ? "✅ Changes Saved!" : "Save Changes"}</Btn>
      </Card>
      <Card>
        <div style={{ fontWeight: 600, color: "#0f172a", marginBottom: 12 }}>Shop Status</div>
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
          <div>
            <div style={{ fontSize: 14, color: "#475569" }}>Currently <b style={{ color: shop?.open ? G : "#dc2626" }}>{shop?.open ? "Open" : "Closed"}</b></div>
            <div style={{ fontSize: 12, color: "#94a3b8" }}>Customers {shop?.open ? "can" : "cannot"} place orders</div>
          </div>
          <Btn variant={shop?.open ? "danger" : "primary"} sm onClick={() => updateShop({ open: !shop?.open })}>
            {shop?.open ? "Close Shop" : "Open Shop"}
          </Btn>
        </div>
      </Card>
      <Card style={{ background: "#f8fafc" }}>
        <div style={{ fontSize: 13, color: "#64748b", display: "flex", flexDirection: "column", gap: 6 }}>
          <div>🥛 <b>{shop?.products?.length || 0}</b> products listed</div>
          <div>📞 {shop?.phone}</div>
          <div>✉️ {shop?.email}</div>
        </div>
      </Card>
    </div>
  );
}
