# DairyDirect 🥛

A full-stack milk dairy management app built with React and Firebase.

## Features
- 👨‍💼 Shop Owner role — manage products, orders, customers
- 🛒 Customer role — browse products, place orders
- 🔐 Firebase Authentication (login / signup)
- 📦 Firestore real-time database

## Tech Stack
- React
- Firebase (Auth + Firestore)
- CSS

## Developer
Made by Sandy | VVP Engineering College
